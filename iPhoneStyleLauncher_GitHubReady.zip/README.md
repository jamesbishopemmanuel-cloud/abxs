# iPhone Style Launcher

A clean Android launcher inspired by modern phone home-screen designs.

## Features

- Android HOME launcher intent
- Dynamic discovery of installed launcher apps
- Real application icons
- App search
- Voice assistant using Android speech recognition
- Voice commands for Settings, Phone, Camera and web search
- Dark modern launcher UI
- Simple dock
- GitHub Actions APK build
- No secrets or API keys included

## Build with GitHub

1. Create a new GitHub repository.
2. Upload this project.
3. Commit to `main`.
4. Open the **Actions** tab.
5. Run **Android Build**.
6. Download the generated APK from the workflow artifacts.

## Important

This project does not contain Apple Siri, Apple source code, Apple trademarks, private APIs, or proprietary Apple assets.

The assistant is an original Android voice-assistant implementation.

For an AI-powered assistant, add your own backend/API securely. Do not put private API keys directly in this Android repository.
