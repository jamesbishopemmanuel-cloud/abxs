package com.example.iphonestylelauncher

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import android.graphics.drawable.BitmapDrawable

data class LauncherApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.Bitmap?
)

class MainActivity : ComponentActivity() {

    private var apps by mutableStateOf<List<LauncherApp>>(emptyList())
    private var speechRecognizer: SpeechRecognizer? = null

    private val microphonePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startAssistant()
            else Toast.makeText(this, "Microphone permission denied", Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadApps()

        setContent {
            LauncherTheme {
                LauncherScreen(
                    apps = apps,
                    onRefresh = { loadApps() },
                    onVoice = { requestMicrophone() }
                )
            }
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val info = it.activityInfo
                val drawable = info.loadIcon(pm)
                val bitmap = (drawable as? BitmapDrawable)?.bitmap
                LauncherApp(
                    label = info.loadLabel(pm).toString(),
                    packageName = info.packageName,
                    icon = bitmap
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun requestMicrophone() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startAssistant()
        } else {
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startAssistant() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition is unavailable", Toast.LENGTH_LONG).show()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "What can I do for you?")
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val command = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.lowercase()
                    ?: return

                handleCommand(command)
            }

            override fun onError(error: Int) {
                Toast.makeText(this@MainActivity, "I couldn't understand that.", Toast.LENGTH_SHORT).show()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("settings") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }

            command.contains("phone") || command.contains("dial") -> {
                startActivity(Intent(Intent.ACTION_DIAL))
            }

            command.contains("camera") -> {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                }
            }

            command.startsWith("search ") -> {
                val query = command.removePrefix("search ").trim()
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra("query", query)
                })
            }

            else -> {
                Toast.makeText(
                    this,
                    "Assistant heard: $command",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(17, 17, 22),
            surface = Color(28, 28, 34)
        ),
        content = content
    )
}

@Composable
fun LauncherScreen(
    apps: List<LauncherApp>,
    onRefresh: () -> Unit,
    onVoice: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var search by remember { mutableStateOf("") }

    val visibleApps = remember(apps, search) {
        apps.filter {
            it.label.contains(search, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(17, 17, 22))
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(32.dp))

        Text(
            text = "9:41",
            color = Color.White,
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(18.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search apps") },
                shape = RoundedCornerShape(25.dp)
            )

            Spacer(Modifier.width(8.dp))

            FilledIconButton(
                onClick = onVoice,
                modifier = Modifier.size(56.dp),
                shape = CircleShape
            ) {
                Text("🎙️", fontSize = 24.sp)
            }
        }

        Spacer(Modifier.height(22.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            items(
                items = visibleApps,
                key = { it.packageName }
            ) { app ->
                AppTile(app) {
                    val launchIntent =
                        context.packageManager.getLaunchIntentForPackage(app.packageName)

                    if (launchIntent != null) {
                        context.startActivity(launchIntent)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(30.dp))
                .background(Color.White.copy(alpha = .10f))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("📞", fontSize = 27.sp, modifier = Modifier.clickable {
                context.startActivity(Intent(Intent.ACTION_DIAL))
            })

            Text("💬", fontSize = 27.sp)

            Text("🌐", fontSize = 27.sp)

            Text("⚙️", fontSize = 27.sp, modifier = Modifier.clickable {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            })

            Text("↻", fontSize = 27.sp, modifier = Modifier.clickable {
                onRefresh()
            })
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun AppTile(
    app: LauncherApp,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        if (app.icon != null) {
            androidx.compose.foundation.Image(
                bitmap = app.icon.asImageBitmap(),
                contentDescription = app.label,
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(15.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(Color.White.copy(alpha = .12f)),
                contentAlignment = Alignment.Center
            ) {
                Text("📱", fontSize = 28.sp)
            }
        }

        Spacer(Modifier.height(5.dp))

        Text(
            text = app.label,
            color = Color.White,
            fontSize = 11.sp,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
    }
}
