# No custom shrinking rules are required for this starter.
