# iPhone Style Launcher — GitHub APK Release

This repository builds the Android launcher and publishes the real APK.

## Get the APK

### Easiest method

1. Upload all files in this project to a GitHub repository.
2. Commit to `main`.
3. Open **Actions**.
4. Select **Build and Release Android APK**.
5. Select **Run workflow**.
6. Wait for the build to finish.
7. Open the workflow run.
8. Download the **iPhoneStyleLauncher-APK** artifact.

The manual workflow also creates a GitHub Release with the APK attached.

### Tag-based releases

You can also create a tag such as:

`v1.0.0`

and push it. The workflow will build the APK and attach it to that GitHub Release.

## Project

The launcher includes:

- Android HOME launcher support
- Dynamic installed-app discovery
- Real app icons
- App search
- Voice assistant foundation
- Voice commands
- Launcher dock
- GitHub Actions Android build
- Automatic APK artifact
- Automatic GitHub Release

## Important

This is an original Android launcher with a Siri-style voice-assistant concept. It does not contain Apple's proprietary Siri software, source code, private APIs, or proprietary Apple assets.

Do not commit private API keys to GitHub.
