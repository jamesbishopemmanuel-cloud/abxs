# iPhone Style Launcher

GitHub-ready Android launcher project.

## APK download

After pushing to GitHub:

1. Open the **Actions** tab.
2. Select **Build Android APK**.
3. Open the successful workflow run.
4. Scroll to **Artifacts**.
5. Download **iPhoneStyleLauncher-APK**.
6. Extract the artifact to get `iPhoneStyleLauncher-debug.apk`.

The workflow deliberately verifies that the APK exists before uploading it.

## Build requirements

- Android SDK 35
- JDK 17
- Gradle 8.10.2
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.21

## Launcher features

- Android Home launcher intent
- Dynamic installed-app discovery
- Real installed application icons
- App search
- Voice assistant foundation
- Voice commands for Settings, Phone, Camera and web search
- Custom launcher dock
- GitHub Actions APK export

## Important

This project does not contain Apple's proprietary Siri, Apple source code, private APIs, or Apple proprietary assets.

The assistant is an original Android voice-assistant implementation.

Do not put private AI/API keys directly inside the Android application or GitHub repository.
